using System;
using System.Diagnostics;
using System.Linq;
using System.Management;

namespace SimpleiPhoneToolkit;

/// <summary>
/// Looks for a connected Apple mobile device via Windows' USB device list.
/// This only detects presence/vendor ID - it does not talk to the device
/// directly. Full device communication (backup, restore, etc.) would need
/// Apple Mobile Device Support (iTunes) or libimobiledevice to be installed.
/// </summary>
public class DeviceManager
{
    // Apple's USB vendor ID.
    private const string AppleVendorId = "VID_05AC";

    public DeviceInfo? DetectDevice()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher(
                "SELECT * FROM Win32_PnPEntity WHERE DeviceID LIKE '%VID_05AC%'");

            foreach (ManagementObject device in searcher.Get())
            {
                var name = device["Name"]?.ToString() ?? "Unknown Apple Device";
                var deviceId = device["DeviceID"]?.ToString() ?? "";

                Logger.Log($"Found candidate device: {name} ({deviceId})");

                return new DeviceInfo
                {
                    Name = name,
                    DeviceId = deviceId,
                    IsAppleDevice = deviceId.Contains(AppleVendorId, StringComparison.OrdinalIgnoreCase)
                };
            }
        }
        catch (Exception ex)
        {
            Logger.Log($"Device detection error: {ex.Message}");
        }

        return null;
    }
}

public class DeviceInfo
{
    public string Name { get; set; } = "";
    public string DeviceId { get; set; } = "";
    public bool IsAppleDevice { get; set; }
}
