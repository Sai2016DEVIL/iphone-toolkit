using System;
using System.IO;

namespace SimpleiPhoneToolkit;

public static class Logger
{
    private static readonly string LogPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "SimpleiPhoneToolkit", "toolkit.log");

    // Raised whenever a new line is logged, so the UI can mirror it live.
    public static event Action<string>? LineLogged;

    public static void Log(string message)
    {
        var line = $"[{DateTime.Now:HH:mm:ss}] {message}";

        try
        {
            var dir = Path.GetDirectoryName(LogPath);
            if (dir != null && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            File.AppendAllText(LogPath, line + Environment.NewLine);
        }
        catch
        {
            // Logging should never crash the app.
        }

        LineLogged?.Invoke(line);
    }
}
