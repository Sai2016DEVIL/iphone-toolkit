# Simple iPhone Toolkit

A Windows Forms app for basic iPhone interaction: detect a connected device,
and integration points to enter/exit Recovery Mode.

## What's included

- `Program.cs`, `MainForm.cs` — the WinForms app and UI
- `DeviceManager.cs` — detects a connected Apple device via Windows WMI/USB
- `RecoveryManager.cs` — integration points for entering/exiting recovery mode
  (actually driving this over USB needs libimobiledevice/libirecovery or
  Apple Mobile Device Support installed — see the `TODO`s in that file)
- `Logger.cs` — writes a log file to `%AppData%\SimpleiPhoneToolkit\toolkit.log`
  and mirrors it live in the app's log panel
- `build.ps1` — builds a single-file, self-contained `.exe`
- `installer\installer.iss` + `build-installer.ps1` — turns that `.exe` into
  a proper Windows installer with Start Menu/Desktop shortcuts and an uninstaller

## Requirements (on your Windows machine)

1. **.NET 8 SDK** — https://dotnet.microsoft.com/download/dotnet/8.0
2. **Inno Setup 6** (free) — https://jrsoftware.org/isinfo.php — only needed
   if you want the installer, not just the raw `.exe`

This project can't be compiled here because it targets Windows Desktop
(WinForms), which requires the actual Windows toolchain to build and run.
Steps 1–3 below are meant to be run on your own Windows PC.

## Step 1 — Build the .exe

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1
```

This produces `publish\SimpleiPhoneToolkit.exe` — a single file, no
install required, no separate .NET runtime needed to run it (it's
self-contained).

If you just want the raw exe with no installer, you're done — copy that
file anywhere and run it.

## Step 2 — Build the installer

```powershell
cd installer
powershell -ExecutionPolicy Bypass -File build-installer.ps1
```

This compiles `installer.iss` with Inno Setup and produces:

```
installer\output\SimpleiPhoneToolkit-Setup.exe
```

That's your installation manager — a standard Windows setup wizard that:
- Installs to Program Files
- Adds Start Menu shortcuts (and optionally a Desktop icon)
- Registers a proper uninstaller in "Apps & Features"

If you prefer a GUI instead of the script, just double-click
`installer.iss` after installing Inno Setup — it opens in the Inno Setup
Compiler, then press **Compile** (Ctrl+F9).

## Notes

- `DeviceManager` detects an Apple USB device via Windows Management
  Instrumentation (vendor ID `05AC`). It doesn't require iTunes to detect
  presence, but deeper device communication (backups, real recovery-mode
  control, etc.) needs libimobiledevice or Apple Mobile Device Support.
- `RecoveryManager`'s enter/exit methods are wired up and logged, but the
  actual USB command to trigger recovery mode is left as a clearly marked
  integration point — plug in your preferred library there.
