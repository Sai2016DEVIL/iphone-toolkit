<#
  build.ps1
  Builds SimpleiPhoneToolkit into a single, self-contained .exe.

  Requirements (on the Windows machine running this script):
    - .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0

  Usage:
    powershell -ExecutionPolicy Bypass -File build.ps1
#>

$ErrorActionPreference = "Stop"

Write-Host "Restoring and publishing SimpleiPhoneToolkit..." -ForegroundColor Cyan

dotnet publish .\iPhoneToolkit.csproj `
    -c Release `
    -r win-x64 `
    --self-contained true `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -o .\publish

if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Build succeeded!" -ForegroundColor Green
Write-Host "Executable created at: .\publish\SimpleiPhoneToolkit.exe"
Write-Host ""
Write-Host "Next step: run installer\build-installer.ps1 (requires Inno Setup)" -ForegroundColor Yellow
