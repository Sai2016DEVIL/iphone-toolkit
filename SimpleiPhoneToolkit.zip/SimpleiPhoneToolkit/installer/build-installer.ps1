<#
  build-installer.ps1
  Compiles installer.iss into a Windows installer .exe using Inno Setup's
  command-line compiler (ISCC.exe).

  Requirements:
    - Inno Setup 6 installed (default path assumed below).
    - Run ..\build.ps1 first so ..\publish\SimpleiPhoneToolkit.exe exists.

  Usage:
    powershell -ExecutionPolicy Bypass -File build-installer.ps1
#>

$ErrorActionPreference = "Stop"

$iscc = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"

if (-not (Test-Path $iscc)) {
    Write-Host "Inno Setup not found at default path." -ForegroundColor Yellow
    Write-Host "Install it from https://jrsoftware.org/isinfo.php, or open installer.iss" -ForegroundColor Yellow
    Write-Host "directly in the Inno Setup Compiler GUI instead." -ForegroundColor Yellow
    exit 1
}

$exePath = Join-Path $PSScriptRoot "..\publish\SimpleiPhoneToolkit.exe"
if (-not (Test-Path $exePath)) {
    Write-Host "Published exe not found at $exePath" -ForegroundColor Red
    Write-Host "Run build.ps1 in the project root first." -ForegroundColor Red
    exit 1
}

Write-Host "Compiling installer..." -ForegroundColor Cyan
& $iscc "$PSScriptRoot\installer.iss"

if ($LASTEXITCODE -ne 0) {
    Write-Host "Installer build failed." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Installer created at: installer\output\SimpleiPhoneToolkit-Setup.exe" -ForegroundColor Green
