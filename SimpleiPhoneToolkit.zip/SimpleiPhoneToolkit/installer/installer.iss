; installer.iss
; Inno Setup script for Simple iPhone Toolkit.
;
; Requirements:
;   - Inno Setup 6: https://jrsoftware.org/isinfo.php (free)
;   - Run build.ps1 first so ..\publish\SimpleiPhoneToolkit.exe exists.
;
; To build the installer:
;   1. Install Inno Setup.
;   2. Open this file in the Inno Setup Compiler, or run from the command line:
;      "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" installer.iss
;   3. Output installer appears in installer\output\SimpleiPhoneToolkit-Setup.exe

#define MyAppName "Simple iPhone Toolkit"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Simple iPhone Toolkit"
#define MyAppExeName "SimpleiPhoneToolkit.exe"

[Setup]
AppId={{8C6F1B2E-4C1A-4B7E-9B2F-2A6F0D1A5E10}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=output
OutputBaseFilename=SimpleiPhoneToolkit-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "..\publish\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent
