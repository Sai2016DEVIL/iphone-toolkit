using System;
using System.Windows.Forms;

namespace SimpleiPhoneToolkit;

public class MainForm : Form
{
    private readonly DeviceManager _deviceManager = new();
    private readonly RecoveryManager _recoveryManager = new();
    private DeviceInfo? _currentDevice;

    private readonly Label _statusLabel;
    private readonly TextBox _logBox;

    public MainForm()
    {
        Text = "Simple iPhone Toolkit";
        Width = 640;
        Height = 460;
        StartPosition = FormStartPosition.CenterScreen;

        var title = new Label { Text = "Simple iPhone Toolkit", Left = 20, Top = 20, AutoSize = true, Font = new System.Drawing.Font(Font.FontFamily, 14, System.Drawing.FontStyle.Bold) };
        _statusLabel = new Label { Text = "No device detected.", Left = 20, Top = 55, AutoSize = true };

        var detectButton = new Button { Text = "Detect Device", Left = 20, Top = 85, Width = 150 };
        var enterRecoveryButton = new Button { Text = "Enter Recovery", Left = 180, Top = 85, Width = 150 };
        var exitRecoveryButton = new Button { Text = "Exit Recovery", Left = 340, Top = 85, Width = 150 };

        _logBox = new TextBox
        {
            Left = 20,
            Top = 130,
            Width = 590,
            Height = 270,
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Vertical,
            Font = new System.Drawing.Font("Consolas", 9)
        };

        detectButton.Click += (s, e) => DetectDevice();
        enterRecoveryButton.Click += (s, e) => _recoveryManager.EnterRecovery(_currentDevice);
        exitRecoveryButton.Click += (s, e) => _recoveryManager.ExitRecovery(_currentDevice);

        Controls.Add(title);
        Controls.Add(_statusLabel);
        Controls.Add(detectButton);
        Controls.Add(enterRecoveryButton);
        Controls.Add(exitRecoveryButton);
        Controls.Add(_logBox);

        Logger.LineLogged += AppendLogLine;
        Logger.Log("Simple iPhone Toolkit started.");
    }

    private void DetectDevice()
    {
        _currentDevice = _deviceManager.DetectDevice();
        _statusLabel.Text = _currentDevice is not null
            ? $"Detected: {_currentDevice.Name}"
            : "No device detected. Connect an iPhone via USB and try again.";
        Logger.Log(_statusLabel.Text);
    }

    private void AppendLogLine(string line)
    {
        if (_logBox.InvokeRequired)
        {
            _logBox.Invoke(() => AppendLogLine(line));
            return;
        }

        _logBox.AppendText(line + Environment.NewLine);
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        Logger.LineLogged -= AppendLogLine;
        base.OnFormClosed(e);
    }
}
